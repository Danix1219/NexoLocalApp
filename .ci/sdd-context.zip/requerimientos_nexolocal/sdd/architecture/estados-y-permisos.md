# Estados, acceso y consistencia de datos

Estado: diseño base del SDD; no implementación. Toda restricción de este archivo debe reflejarse en el contrato del propietario y en sus pruebas. Los DTO no incluyen campos prohibidos aunque Flutter pudiera ocultarlos.

## Pedido: autoridad S04

| Estado actual | Acción | Actor | Nuevo estado | Efectos dentro del commit |
|---|---|---|---|---|
| Sin pedido | Crear | Cliente autenticado | pend | Validar perfil/categoría/modalidad/contexto; deduplicar; escribir outbox |
| pend | Aceptar | Prestador destinatario | ok | Asignar solicitud si existe, guardar precio opcional y publicar evento |
| pend | Rechazar | Prestador destinatario | cancel | Liberar referencia y retirar acceso a datos precisos |
| pend u ok | Cancelar | Cliente o prestador participante | cancel | Liberar asignación según política; invalidar permisos y evento |
| ok | Resolver | Prestador destinatario | done | Cerrar solicitud y habilitar opinión del cliente |
| done o cancel | Cualquiera de las anteriores | Cualquier actor | Sin transición | Rechazar conflicto; no reabrir implícitamente |

Repetir un comando con la misma Idempotency-Key y cuerpo conserva resultado; distinta carga con misma clave produce conflicto. If-Match/version evita sobrescribir una transición concurrente. Aceptar dos pedidos sobre una solicitud deja una sola asignación activa, mediante transacción S04 e índice único parcial. Una entrega duplicada de evento no duplica efectos en S05/S07.

## Matriz de datos privados

| Recurso/campo | Dueño | Contraparte pendiente | Contraparte ok | Contraparte done | Cancelado | Visitante/tercero |
|---|---|---|---|---|---|---|
| Domicilio cliente | Acceso al propio según retención | Solo zona | Prestador asignado autorizado | Propuesta: hasta siete días de cierre, por ratificar | Solo zona para contraparte | Nunca preciso |
| Teléfono cliente | Acceso al propio | No | Solo prestador asignado con both vigente | Misma restricción mientras acceso siga vigente | No para contraparte | Nunca |
| Teléfono prestador | Acceso al propio | Solo si showPhone vigente y consumidor autorizado | Misma política | Misma política | No por pedido; acceso general independiente requiere política propia | No en DTO público cacheado |
| Origen privado del prestador | Propietario | No | No por aceptar pedido | No | No | No |
| Dirección comercial pública | Propietario | Solo si publicada explícitamente | Igual | Igual | Igual, independiente del pedido | Sí si publicación comercial explícita |
| Mensaje/foto de chat | Miembros habilitados | Miembros según conversación | Igual | Según retención | Cancelar no publica historial | Nunca |
| Guardados y experiencias propias | Cuenta propietaria por userId/authorId | No como propios | No como propios | No como propios | No como propios | Solo experiencias públicas autorizadas, nunca guardados privados |

El plazo de domicilio done, retención de chat y acceso histórico deben ratificarse antes de Ready de 007/008. Un bloqueo afecta envíos y acceso de contacto conforme a política del contrato, sin eliminar arbitrariamente evidencia histórica. Baja/suspensión o fallo de la consulta de política no concede acceso por omisión.

## Modos y caché

Cambiar Cliente/Proveedor solo cambia presentación. Derivar propietario y capacidades del JWT/sesión y perfil real. Usar UUID para cuenta/perfil; los alias locales me y Tú no salen como identidades del backend. SQLite, borradores y caché privados usan namespace de cuenta, se purgan al logout y no se mezclan al iniciar con otra.

## Escritura y proyecciones

S01 decide cuenta/sesión; S02 perfil/canales/cobertura; S03 autoría/comunidad; S04 asignación/contacto cliente; S05 membresía/bloqueo/mensajes; S06 medios/reportes; S07 notificaciones. S08 solo proyección. Cambios críticos se verifican en propietario, sin esperar a eventos o caché del grafo. Las proyecciones revalidan visibilidad antes de responder; no almacenan credenciales, teléfono o domicilio.
