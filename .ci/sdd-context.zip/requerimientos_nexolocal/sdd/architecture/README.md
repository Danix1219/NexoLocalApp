# Arquitectura de producto y organización del desarrollo

Estado: propuesta de detalle a partir de la arquitectura 1.2.0. No confundir arquitectura distribuida con SDD: SDD gobierna cómo se decide, implementa y verifica esa arquitectura.

Las invariantes y permisos privados están detallados en [estados y permisos](estados-y-permisos.md). Sus propuestas de retención deben ratificarse antes de desarrollar el recorrido afectado.

```mermaid
flowchart LR
  F[Flutter] --> G[G01 Gateway HTTPS]
  G --> I[S01 Identidad]
  G --> D[S02 Directorio]
  G --> C[S03 Comunidad]
  G --> O[S04 Solicitudes y pedidos]
  G --> M[S05 Mensajería]
  G --> T[S06 Confianza y contenido]
  G --> N[S07 Notificaciones]
  C --> E[Outbox y colas por consumidor]
  D --> E
  O --> E
  E --> N
  E --> R[S08 Grafo opcional]
  R --> Q[Lectura GraphQL opcional]
  M --> W[WebSocket de avisos]
```

El diagrama resume dependencias; no enumera todos los contratos. REST cubre acciones y lectura persistente. WebSocket avisa, nunca sustituye historial. Colas distribuyen eventos con outbox/inbox. GraphQL es interfaz opcional de S08, no consecuencia obligatoria de usar Neo4j.

## Interior de cada microservicio: propuesta de arquitectura hexagonal

La documentación anterior describe separación de reglas/repositorios/adaptadores. Para hacerla consistente se propone formalizar puertos y adaptadores: dominio con invariantes; aplicación con casos de uso; puertos de persistencia/integraciones; adaptadores HTTP, MongoDB, Redis y proveedores externos; host con configuración. Domain no importa SDK de nube, HTTP o MongoDB. Los límites de transacción permanecen en un agregado o servicio propietario.

Repository encapsula persistencia; Adapter encapsula SMS/mapas/IA/almacenamiento. Dependency Injection compone implementaciones. Aplicación autoriza y coordina cada caso de uso; gateway no concentra reglas de negocio. Evitar CRUD genérico que permita saltar transiciones o moderación. Hexagonal es decisión propuesta nueva, no una implementación previa ya aprobada.

## Flutter: presentación, aplicación y datos por funcionalidad

MVVM como propuesta de presentación: View renderiza estado y envía intenciones; ViewModel gobierna carga/error/estado; casos de uso coordinan repositorios; repositorios combinan API/SQLite; adaptadores consumen contratos. Reglas autoritativas de pedidos y permisos siguen en backend. Riverpod/go_router son recomendaciones previas por fijar, no requisitos académicos. Separar almacenamiento por cuenta y purgarlo al salir.

## Datos y consistencia

S01 nl_identity; S02 nl_directory; S03 nl_community; S04 nl_orders; S05 nl_messaging; S06 nl_trust + objetos; S07 nl_notifications. Un clúster compartido inicial no permite acceso cruzado. S08 consume proyecciones sin teléfono/domicilio; su caída no impide búsqueda básica ni pedidos. Restricciones e índices pertenecen a cada servicio. Redis de seguridad necesita política distinta de caché expulsable.

## Estructura futura del repositorio: propuesta, no carpetas implementadas

```text
apps/mobile/                 Flutter por funcionalidades y repositorios
apps/landing/                Sitio de soporte, Play, privacidad y analítica
gateway/                     Entrada HTTPS y composición
services/<servicio>/
  src/Domain/                Entidades, estados e invariantes
  src/Application/           Casos de uso, puertos y autorización
  src/Infrastructure/        Persistencia e integraciones
  src/Api/                   DTO, rutas, middleware y composición
  tests/                     Dominio, integración y contratos
contracts/                   Esquemas formales publicados por propietario
infra/                       IaC y configuración por entorno
pipelines/                   Entrega y controles
sdd/                         Especificación y trazabilidad
```

Se recomienda monorepositorio inicial para trazabilidad y cambios coordinados, con despliegue/versionado independiente por servicio. Esto no implica monolito. No crear todavía soluciones, contenedores ni dependencias: primero cerrar stack y primer recorrido. Cuando existan contratos formales en `/contracts`, mover allí la autoridad desde este registro sin mantener copias divergentes.
