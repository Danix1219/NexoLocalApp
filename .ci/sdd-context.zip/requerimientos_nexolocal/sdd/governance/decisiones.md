# Registro de decisiones y preguntas abiertas

Fecha: 2026-11-02. Confirmado significa indicado por el usuario o exigido por Móvil v2; propuesto requiere ratificación antes de implementar lo que depende de ello.

| ID | Decisión | Estado | Consecuencia |
|---|---|---|---|
| D01 | Flutter para móvil Android | Confirmado por usuario | Mantener frontend móvil |
| D02 | Microservicios por dominio y APIs | Dirección confirmada | Separación de datos y despliegues |
| D03 | Bases centrales NoSQL, Redis, dos instancias HTTP, TLS y controles académicos | Obligación documental | Verificar requisitos antes de entrega |
| D04 | .NET 10 y gateway YARP | Propuesto en 1.2.0 | Fijar SDK/parche y librerías antes de código |
| D05 | MongoDB por servicio, Redis y Blob/CDN | Propuesto en 1.2.0 | Probar consultas, costos y acceso |
| D06 | Azure como nube | Propuesto, costo pendiente | No provisionar recursos facturables por este documento |
| D07 | Neo4j y GraphQL de lectura S08 | Propuesto y condicionado | Ensayo/costo; no bloquea MVP existente |
| D08 | Hexagonal por servicio, MVVM por feature Flutter | Propuesto en SDD | Dependencias hacia dominio/puertos |
| D09 | Monorepositorio con despliegues independientes | Propuesto en SDD | Un cambio puede coordinar varios consumidores |
| D10 | SDD por recorrido vertical y contratos primero | Propuesta de proceso | Evidencia por historia, no completar servicios enteros aislados |

## Información faltante y a quién corresponde resolverla

| Pendiente | Responsable funcional | Bloquea |
|---|---|---|
| Ratificar D04/D05/D08/D09 y fijar versiones exactas | Responsable técnico/producto | Crear proyectos del primer recorrido |
| Equipo, responsables y capacidad semanal | Equipo | Fechas y asignación de tareas |
| Cuenta/región/créditos y significado de costo cero | Infraestructura/docente | Despliegue de evaluación |
| Proveedor y credenciales SMS de México | Identidad | OTP real y aceptación del recorrido 001 |
| Titular, contacto, privacidad y retención | Producto | Avisos finales, borrado y publicación |
| Contrato de categorías/unidades/materiales/completitud | Producto | Comparación y perfil finales |
| Proveedores/moderación y modelos ML/GenAI | Contenido/móvil | Ingesta real, IA y evaluación |
| Cuenta Play, firma y dominio | Entrega | Distribución y deep links |
| Entrevistas y proyectos del docente | Producto/SDD | Evidencia académica específica |

No se convierten estos pendientes en aprobaciones por silencio. Se puede seguir refinando documentación y contratos de dominios independientes. La evaluación de 2 de diciembre de 2026 se conserva como fecha del documento fuente; confirmar vigencia con el docente antes de comprometer calendario.
