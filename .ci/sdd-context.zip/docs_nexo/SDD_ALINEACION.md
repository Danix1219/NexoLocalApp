# Acuerdo de trabajo SDD — API y app

Fecha: 2026-11-02. Estado: redefinición documental propuesta; pendiente de revisión humana. No autoriza implementación ni publicación.

## 1. Autoridad y fuentes

Los [lineamientos Móvil v2](Requerimientos para el desarrollo del proyecto Móvil v2.pdf) fijan obligaciones académicas; la maqueta aprobada fija funciones visibles. [Requisitos y arquitectura 1.2.0](Nexo_Local_Requerimientos_y_Arquitectura.md) y la [auditoría H01–H12](Nexo_Local_Auditoria_Modulos_y_Grafo.md) concilian el alcance ampliado. La [propuesta original](Nexo_Local_Propuesta_de_proyecto.pdf) aporta contexto; su exclusión de chat fue superada por la maqueta. El [libro de matrices](Nexo_Local_Matrices.xlsx) es línea base de diseño, no evidencia de implementación.

La elección de Codex y Claude Code sustituye OpenCode/WARP como herramientas del equipo. El punto 6 de Móvil v2 las permite: OpenCode es sugerencia. Flutter, microservicios y NoSQL son la dirección de producto; .NET/YARP, MongoDB, Azure y bibliotecas concretas conservan su condición de propuesta hasta ratificación. Redis distribuido, dos instancias, TLS, CI/CD y CDN no pueden eliminarse por comodidad del ejemplo.

Cada constitución manda en su contexto; AGENTS describe el procedimiento. Si una fuente funcional y una decisión técnica discrepan, registrar la diferencia, actualizar la spec afectada y obtener revisión antes de Ready. No reinterpretar un defecto del prototipo como permiso de producción. No modificar API_SDD ni WebSDD.

## 2. Estructura y responsabilidades

| Contexto | Secuencia conservada | Autoridad |
|---|---|---|
| API_NexoLocal | spec.md → plan.md → task.md → checklists/gates.md | Contratos, permisos, estados, datos propios, eventos y operación backend |
| App_NexoLocal | spec.md → plan.md → tasks.md → checklist.md | Pantallas, navegación, estado, permisos Android, persistencia local y consumo |
| docs_nexo | Fuentes y acuerdos comunes enlazados | Línea base, cobertura, decisiones abiertas y protocolo compartido |

La spec describe actores, necesidad, reglas FR/NFR y aceptación. El plan identifica la solución y sus riesgos. Las tareas son unidades revisables con requisito, criterio y dependencia. El checklist enlaza evidencia real y revisión. El número de fase no es versión de producto ni una autorización de construirla completa.

## 3. Preparación, ejecución y cierre

1. Leer constitución, AGENTS, Memoria, fuente y spec de ambas partes afectadas.
2. Refinar una historia: actor, precondiciones, reglas, ejemplos positivos/negativos, dependencia y exclusiones. Identificar cada requisito como contexto/spec/FR o NFR; los IDs son locales.
3. Formalizar únicamente los contratos de la historia y registrar consumidor, versión y compatibilidad. No implementar con formalContract=null.
4. Revisar plan, tareas, privacidad, fallos y criterios. Ready exige decisiones bloqueantes resueltas y revisor humano identificado. Aprobar documentación no autoriza automáticamente código.
5. Tras un encargo posterior, construir un incremento acotado y ejecutar pruebas reales. Preparar CI, versiones y canal Play desde la primera vertical; la fase de entrega cierra evidencia global.
6. Conciliar los cuatro documentos, contratos, consumo, Memoria y checklist de PR. Registrar herramienta/modelo declarado, archivos, versión o commit si existe, comando, resultado y limitaciones. Una revisión de IA no sustituye la firma humana.

Estados: Borrador documental → refinada → lista para desarrollar → implementada con evidencia → aprobada. No avanzar por existencia de archivos o por un PASS estructural. Un N/A incluye razón y revisión; no equivale a PASS.

## 4. Frontera API–Flutter

La [autoridad de contratos](../API_NexoLocal/docs/contracts/README.md) y su inventario pertenecen a API. La app [registra consumo](../App_NexoLocal/docs/endpoints-ui.md) sin duplicar payloads. Las 101 operaciones son catálogo: no son OpenAPI implementado. Antes de consumo: tipos, requeridos/nulos, enums, permisos por campo, errores, paginación, reintentos, idempotencia, compatibilidad y ejemplos sintéticos.

REST público usa /api/v1 como base; /internal y /health conservan superficie propia; /ws/v1/chat y /graphql/social/v1 se definen por separado. Flutter no invoca operaciones internas/admin ni lee MongoDB, Redis o Neo4j. Los contratos formales y generadores se incorporarán en una fase posterior.

La API autoriza por identidad estable y estado actual. Flutter presenta y revalida; el modo solicitante/prestador no concede privilegios. La API confirma persistencia; la UI distingue pendiente, confirmado, rechazado y fallo recuperable. Un timeout no demuestra fracaso del comando: reintentar con la misma clave cuando corresponda.

## 5. Casos transversales obligatorios

| Riesgo | Backend | Flutter y comprobación conjunta |
|---|---|---|
| Identidad H03 | sub/sid, autoría por ID, refresh rotatorio y revocación compartida | Almacenamiento seguro, caché/SQLite/borradores por cuenta; Ana sale y Carlos entra sin datos residuales |
| Contacto H01/H02 | Comprobar participante, consentimiento y estado ok/done; cancelación retira precisión | No conservar teléfono/ruta privada tras cancelación, logout o pérdida de permiso |
| Moderación | Revisar texto/imagen antes de persistir; aprobación ligada a hash/autor/finalidad; fallo cerrado | Conservar borrador local privado; mostrar rechazo/reintento, nunca publicación ficticia |
| Concurrencia | Versión e idempotencia; pedido/asignación/outbox en transacción local S04 | No aceptar doble tap como dos pedidos; conflicto exige refrescar |
| Mensajes H05/H11 | Historial durable, deduplicación y contexto por mensaje | Manual/rápido comparten envío; reconexión por cursor y estados pendiente/confirmado |
| Borrado | Bloqueo inmediato y saga con confirmación de cada propietario habilitado | Purga local, trámite pendiente visible y consulta de estado sin afirmar completado antes |
| Offline | Servidor conserva autoridad; revalidar estados al sincronizar | Lecturas públicas marcadas con antigüedad; no aceptar pedidos, autorizar contacto ni moderar offline |

Los borradores locales de contenido aún no enviado no equivalen a publicación. Definir cifrado/protección y retención al ratificar almacenamiento. No almacenar cuerpos rechazados en logs, temporales, Blob o CDN. Las push incluyen referencias mínimas y revalidan acceso al abrir.

## 6. Dependencias e incrementos

Fundamentos API nv-00→nv-01→nv-02→nv-03; app 001→002→003. Identidad mínima nv-04/004 consume EP-001/002/003/004/005/007/008. Recuperación, sesiones y eliminación son subincrementos posteriores, sin fingir que el subset los entrega. Moderación precede a escritura de contenido público.

Comunidad declarada puede avanzar antes de pedidos; experiencia vinculada espera elegibilidad de nv-10. Pedido desde perfil/candidato puede avanzar antes de chat; la entrada desde chat se completa con nv-11. Feed público empieza con directorio y añade comunidad cuando exista. Notificaciones y borrado crecen con cada servicio, no se posponen íntegramente a nv-12. S08 y shortlist permanecen opcionales.

## 7. Decisiones todavía abiertas

| ID | Decisión | Responsable funcional por asignar | Bloquea |
|---|---|---|---|
| D01 | Ratificar .NET/YARP, MongoDB, proveedor de eventos y versiones | Arquitectura backend | Plan técnico Ready de la primera vertical |
| D02 | Ratificar MVVM, estado, navegación, SQLite y almacenamiento seguro | Arquitectura móvil | Plan técnico Ready móvil |
| D03 | Nube/región, dos réplicas, Redis/CDN y significado verificable de costo cero | Infraestructura y docente | Provisionamiento/despliegue; no el análisis documental |
| D04 | Proveedor SMS y moderación, credenciales y cuotas | Identidad/confianza | Aceptación real; dobles solo en pruebas acotadas |
| D05 | Titular, contacto de privacidad, retención/backups y consentimiento | Producto | Aceptación de privacidad, borrado y publicación |
| D06 | ML: dataset/modelo/métricas; GenAI: proveedor, cuota, seguridad y evaluación | Móvil/backend | Aceptación nv-13/013; edición manual sigue disponible |
| D07 | Cuenta GitHub única, accesos, carpeta compartida y Play Console | Gestión/entrega | Publicación y paquete evaluable |
| D08 | Entrevistas, repositorios docentes/commit y responsables humanos vigentes | Producto/equipo | Cierre académico y ratificación |

No se inventan nombres, aprobaciones, fechas de ratificación ni precios. El expediente académico señala evaluación el 02/12/2026; el cronograma se estima con capacidad real del equipo.

## 8. Evidencia mínima por tarea

Registrar contexto/spec/T-ID; requisito y AC; fecha; herramienta y modelo si se conoce; entrada sin secretos; archivos; contrato; entorno; versión/commit disponible; comando exacto y salida/exit; tipo de evidencia (documental, unitario con doble, integración real, dispositivo o despliegue); limitación; pendiente; revisor humano y fecha reales. Sin Git, registrar que no existe commit y usar hash documental si hace falta reproducibilidad.

Los validadores actuales verifican estructura/enlaces y algunas referencias. No validan semántica completa, compatibilidad de API, seguridad, accesibilidad, Android, cuotas o revisión humana.

## 9. Aplicación estructural 0.3.0

Ver [cierre y ubicación de brechas](SDD_CIERRE_ESTRUCTURA.md). Cada contexto incorpora mapa local de carpetas/autoridad y trazabilidad por sección constitucional. Las specs contienen tabla FR/NFR→tarea→AC con tareas realmente definidas; revisar también dependencias sin ciclos.

La app incorpora 016-sincronizacion-local para cola permitida, migraciones, conflicto, respuesta tardía y cambio de cuenta: capacidades existentes en fuente 1.2.0 antes dispersas. Se prepara con 003/004, integra 007/008 y debe aceptarse antes del cierre 014. No crea nuevas operaciones de backend ni permite acciones críticas offline. API conserva 16 fases con sus tareas transversales integradas.

## 10. Cobertura funcional vigente 0.4.0

El [mapa funcional](SDD_COBERTURA_FUNCIONAL.md) sustituye las asignaciones agregadas anteriores: 26 specs API y 25 móviles, sin crear endpoints o microservicios. El catálogo mantiene 101 operaciones con spec primaria única; 92 tienen intención consumidora móvil y 9 exclusión directa por superficie. Cada operación tiene FR/T/AC propios, además de historias para 13 componentes backend, 27 móviles, W01, 19 puntos académicos, seis tareas previas y H01–H12.

Las fases origen conservan integración de experiencia, mientras los casos de uso trasladados se construyen solo en su spec primaria. 016 sincroniza guardados con app 019; notificaciones pasan a API nv-21/app 022; recuperación/sesiones a API nv-16/app 017; experiencias a API nv-19/app 020; contacto a 025 en ambas. La entrega integrada verifica todas las capacidades obligatorias. Dependencia de cierre no bloquea el subset previo que tiene contrato y precondiciones propios. Las referencias 0.2/0.3 son históricas.
