# Codex y Claude Code — procedimiento del equipo

Fecha: 2026-11-02. Aplicable a API y app, sujeto al encargo vigente. OpenCode/WARP queda únicamente como referencia histórica docente.

## Entradas persistentes

Codex usa AGENTS.md. Claude Code dispone de CLAUDE.md como entrada que remite al mismo AGENTS, constitución y Memoria. No mantener dos versiones de reglas. La documentación oficial explica [AGENTS y skills de Codex](https://learn.chatgpt.com/docs/customization/overview) y [memoria/instrucciones de Claude Code](https://code.claude.com/docs/en/memory). Se verificaron estas fuentes el 02/11/2026; confirmar soporte de la versión instalada al activar configuraciones.

Los archivos documentan reglas; no prueban que una herramienta los haya cargado. Antes de trabajar, el agente identifica contexto, spec/tarea, archivos permitidos, fuentes, dependencias y criterios. No inferir instalación o permisos porque exista un README.

## Roles secuenciales

| Rol | Trabajo | Salida |
|---|---|---|
| Planificación | Conciliar fuentes, alcance, FR/NFR y preguntas | Spec y decisiones abiertas |
| Arquitectura/contratos | Diseñar propietario, interfaz y fallos | Plan y contrato único |
| Construcción futura | Ejecutar una tarea autorizada | Cambio acotado y explicación |
| Seguridad/QA | Revisar negativos, aislamiento, concurrencia y proveedores | Hallazgos y pruebas realmente ejecutadas |
| Trazabilidad/documentación | Conciliar documentos y evidencia | Checklist y Memoria |
| Revisión humana | Ratificar alcance/decisiones y aceptar resultados | Nombre, fecha y decisión reales |

Codex o Claude Code pueden asumir cualquiera de los roles. Usar el segundo para revisión es una posibilidad secuencial, no garantía de independencia ni aprobación humana. La tabla no habilita subagentes o ejecución paralela; se requiere autorización explícita para delegar.

## Traspaso entre herramientas

Registrar en Memoria o evidencia de tarea: contexto/spec/T-ID, objetivo, requisitos, documentos leídos, archivos cambiados, decisiones y preguntas, último comando/resultado y siguiente paso. La siguiente herramienta vuelve a leer los archivos actuales y comprueba cambios antes de editar. Solo una sesión escribe los mismos archivos a la vez.

La herramienta entrante no presupone que los tests pasaron ni repite automáticamente operaciones externas. Conservar datos sintéticos; excluir tokens, claves, direcciones, conversaciones e imágenes privadas. La memoria global de cada asistente no sustituye la bitácora del proyecto.

## Instrucción de inicio reutilizable

Trabaja en el contexto indicado. Lee constitución, AGENTS, Memoria y la spec objetivo. Atiende únicamente la tarea y los FR/NFR indicados, con sus criterios. Consulta el contrato autoritativo y la spec del otro contexto si afecta la frontera. En fase documental modifica solo documentación. Registra dudas bloqueantes, resultados reales y pendientes. No actives subagentes, instalaciones, infraestructura o publicaciones por la mera existencia de roles o skills.

## Skills y MCP

Una skill describe un procedimiento; un MCP ofrece herramientas. Ninguno sustituye una regla de negocio ni amplía el encargo. Leer instrucciones y revisar scripts, escrituras, red y permisos antes de adoptar una skill. No copiar configuración de OpenCode a Codex o Claude Code. Ver [selección y compatibilidad](SDD_SKILLS.md).
