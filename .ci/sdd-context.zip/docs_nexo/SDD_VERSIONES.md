# Versionamiento previo al desarrollo

Fecha: 2026-11-02. Propuesta pendiente de ratificación. La revisión funcional vigente del SDD es 0.4.0; las constituciones conservan sus reglas 0.3.0 y las fuentes adjuntas siguen 1.2.0. Son versiones de artefactos distintos, no versiones de producto publicado.

| Elemento | Regla | Inicial propuesta; no publicada |
|---|---|---|
| G01 y cada S01–S07 | SemVer independiente por artefacto | 0.1.0 |
| S08 | SemVer solo si se habilita | 0.1.0 opcional |
| App Flutter | versionName SemVer y versionCode entero creciente global | 0.1.0+1 |
| Landing | SemVer independiente y hash/commit | 0.1.0 |
| REST público | Versión mayor en base URL | /api/v1 |
| OpenAPI | info.version y referencia de revisión | Por formalizar por historia |
| WS | Ruta y envelope con versión | /ws/v1/chat propuesto |
| Eventos | Tipo estable y schemaVersion | 1 propuesto |
| Datos remotos y SQLite | schemaVersion y migraciones numeradas por propietario | 1 propuesto |
| Infraestructura | Revisión de módulos/lock, entorno y manifiesto | 0.1.0 propuesto |

PATCH corrige manteniendo compatibilidad; MINOR añade capacidad compatible; MAJOR rompe contrato. Un cambio incompatible exige convivencia y migración para apps ya distribuidas, no solo desplegar ambos repositorios a la vez. No reutilizar versionCode ni tags. El identificador V1.00.002 de la maqueta no es versión de app implementada.

Cada despliegue futuro registra releaseId, fecha UTC, entorno, ejecutor real, specs/tareas, commit si existe, versión de servicios/landing/app, revisión de contratos/eventos/datos, migraciones, digest de imagen, AAB/hash, versionCode, revisión de infraestructura, pruebas y reversión. Si todavía no hay Git o artefacto, esos valores quedan pendientes explícitos.

Ratificar responsable y política en nv-00/nv-02 y app 001/003 antes de implementar. nv-14/014 verifican el manifiesto final, compatibilidad y recuperación; CI/CD se prepara desde la primera vertical.
