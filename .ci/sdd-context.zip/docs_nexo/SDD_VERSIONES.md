# Versionamiento previo al desarrollo

Actualizacion documental: 2026-11-03. Propuestas de producto pendientes de ratificacion. API nv-00 esta en 0.4.2 de preparacion y las demas specs API en 0.4.1; constitucion API 0.3.1 documental. App conserva revision funcional 0.4.0 y constitucion 0.3.0. Fuentes adjuntas 1.2.0 y snapshots congelados conservan su revision. Ninguna de estas cifras equivale a version de producto publicado.

| Elemento | Regla | Inicial propuesta; no publicada |
|---|---|---|
| G01 y cada S01–S07 | SemVer independiente por artefacto | 0.1.0 |
| S08 | SemVer solo si se habilita | 0.1.0 opcional |
| App Flutter | versionName SemVer y versionCode entero creciente global | 0.1.0+1 |
| Landing | SemVer independiente y hash/commit | 0.1.0 |
| REST público | Versión mayor en base URL | /api/v1 |
| OpenAPI | info.version y referencia de revisión | Por formalizar por historia |
| WS | Ruta y envelope con versión | /ws/v1/chat propuesto |
| Eventos | Tipo estable y schemaVersion | 1 propuesto |
| Datos remotos y SQLite | schemaVersion y migraciones numeradas por propietario | 1 propuesto |
| Infraestructura | Revisión de módulos/lock, entorno y manifiesto | 0.1.0 propuesto |

PATCH corrige manteniendo compatibilidad; MINOR añade capacidad compatible; MAJOR rompe contrato. Un cambio incompatible exige convivencia y migración para apps ya distribuidas, no solo desplegar ambos repositorios a la vez. No reutilizar versionCode ni tags. El identificador V1.00.002 de la maqueta no es versión de app implementada.

Cada despliegue futuro registra releaseId, fecha UTC, entorno, ejecutor real, specs/tareas, commit si existe, versión de servicios/landing/app, revisión de contratos/eventos/datos, migraciones, digest de imagen, AAB/hash, versionCode, revisión de infraestructura, pruebas y reversión. Si todavía no hay Git o artefacto, esos valores quedan pendientes explícitos.

Ratificar responsable y política en nv-00/nv-02 y app 001/003 antes de implementar. nv-14/014 verifican el manifiesto final, compatibilidad y recuperación; CI/CD se prepara desde la primera vertical.

## Revision documental de estructura backend 0.4.1

API: specs 0.4.1 y constitucion 0.3.1 documental, ambas pendientes de revision/ratificacion. Integra preparacion de rutas/propietario y tareas de consolidacion/CI, sin cambiar contratos, endpoints, servicios implementados o versiones de producto. App conserva revision funcional 0.4.0; no se fuerza una version movil por un cambio de proceso backend. Los snapshots CI existentes siguen congelados en su revision 0.4.0, no se anuncian como HEAD vivo. Estado y evidencia: [integracion de estructura](SDD_INTEGRACION_ESTRUCTURA_BACKEND.md). No publicado mientras los datos Jira/Confluence sigan pospuestos.

## Base tecnica local creada (2026-11-03)

Scaffold autorizado sin negocio: solucion NexoLocal.Backend.slnx y cuatro proyectos Identity net10.0 en nexolocal.Api; SDK 10.0.302 con latestPatch y sin prerelease, observado localmente. Sin PackageReference en los cuatro proyectos, sin tags/versiones de producto ni despliegue. Build local correcto; workflow preparado no ejecutado en remoto. [Evidencia](../API_NexoLocal/docs/inicio-backend/base-fisica.md). Las ratificaciones de proveedores y contratos siguen pendientes.

## Correccion de base por microservicios (2026-11-03)

Sustituye la descripcion anterior de solucion paralela: unica solucion nexolocal.Api.slnx; proyecto original nexolocal.Api es G01 Gateway y S01 tiene host propio en services/identity/src/Api. Cinco proyectos, dos hosts/artefactos independientes, SDK/target sin cambio. No nuevo producto/tag ni proveedor ratificado. [Evidencia vigente](../API_NexoLocal/docs/inicio-backend/correccion-base-microservicios.md).
